#ifndef SOFTWARECAD123_H
#define SOFTWARECAD123_H

namespace RemoteDesktop{
	bool IsSASCadEnabled();
	void Enable_SASCAD();
}


#endif