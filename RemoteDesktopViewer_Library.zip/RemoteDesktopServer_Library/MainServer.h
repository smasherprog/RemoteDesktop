#ifndef MAINSERVER123_H
#define MAINSERVER123_H

namespace RemoteDesktop{
	void Startup(LPWSTR* argv, int argc, bool startasproxy);
}

#endif