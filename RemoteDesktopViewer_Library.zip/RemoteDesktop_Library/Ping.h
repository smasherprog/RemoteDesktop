#ifndef PING123_H
#define PING123_H

namespace RemoteDesktop{
	bool Ping(wchar_t* ip);
}

#endif