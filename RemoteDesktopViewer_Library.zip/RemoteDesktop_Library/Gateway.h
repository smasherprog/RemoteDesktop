#ifndef GATEWAY123_H
#define GATEWAY123_H

namespace RemoteDesktop{
	bool GetGatewayID_and_Key(int& id, std::wstring& aeskey, std::wstring gatewayurl);
}


#endif