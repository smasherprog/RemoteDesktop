#ifndef ADMINSTATUS123_H
#define ADMINSTATUS123_H

namespace RemoteDesktop{
	bool IsUserAdmin();
}
#endif