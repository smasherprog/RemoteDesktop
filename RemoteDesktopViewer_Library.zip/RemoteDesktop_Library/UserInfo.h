#ifndef USERNAMEINFO123_H
#define USERNAMEINFO123_H
#include "CommonNetwork.h"

namespace RemoteDesktop{
	User_Info_Header GetUserInfo();
	std::string get_ActiveUser();
}

#endif