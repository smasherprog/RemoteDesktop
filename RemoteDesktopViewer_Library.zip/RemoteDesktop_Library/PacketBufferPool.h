#ifndef PACKETBUFFERPOOL123_H
#define PACKETBUFFERPOOL123_H

namespace RemoteDesktop{
	class PacketBufferPool{


	};
}

#endif
